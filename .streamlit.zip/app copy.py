import streamlit as st
import pandas as pd
import re
from io import BytesIO

# 🚨 Config inicial do Streamlit
st.set_page_config(page_title="Conversor de OFX para XLSX", layout="centered")

# 🎨 Estilo visual da página com base na identidade da Movendo
st.markdown("""
    <style>
        html, body {
            font-family: 'Open Sans', sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding-bottom: 60px;
            height: 100%;
        }
        .header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 1em;
        }
        .header img {
            height: 50px;
            border-radius: 8px;
        }
        .title {
            color: #5ebc67;
            font-weight: 800;
            font-size: 2.5em;
        }
        h2 {
            color: #007a77;
        }
        div.stDownloadButton > button {
            background-color: #ff932b;
            color: white;
            font-weight: bold;
            border-radius: 100px;
            padding: 0.75em 2em;
            transition: all 0.3s ease-in-out;
        }
        div.stDownloadButton > button:hover {
            background-color: #007a77;
            color: #ffffff;
        }
        section[data-testid="stFileUploader"] {
            background-color: #ffffff;
            border: 2px dashed #5ebc67;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 2em;
        }
        .stDataFrame {
            border-radius: 10px;
            overflow: hidden;
        }
        footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            background-color: #e6f2e8;
            color: #2d6a4f;
            text-align: center;
            padding: 10px 0;
            font-weight: 600;
            font-size: 0.95em;
            box-shadow: 0 -2px 5px rgba(0,0,0,0.1);
            z-index: 100;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 6px;
        }
        footer .heart {
            color: #5ebc67;
            font-size: 1.2em;
            transform: translateY(1px);
        }
    </style>
""", unsafe_allow_html=True)

# 🟢 Header da página
st.markdown("""
    <div class="header">
        <img src="https://pages.greatpages.com.br/www.movendo.com.br/1744681213/imagens/desktop/49713-f001ad13d8ae3e8304461f490af9f362.png" alt="Logo Movendo" />
        <div class="title">Conversor de OFX para XLSX</div>
    </div>
""", unsafe_allow_html=True)

# 📥 Upload do OFX
uploaded_file = st.file_uploader("Envie o arquivo .OFX", type=["ofx"])

if uploaded_file is not None:
    try:
        # 🔄 Lê o conteúdo e decodifica em latin-1 (bancos usam bastante isso)
        content = uploaded_file.read()
        decoded = content.decode('latin-1')

        # 🔍 Extrai apenas os blocos de transação (isso evita confusão com <FITID> soltos fora do contexto)
        raw_transactions = re.findall(r"<STMTTRN>(.*?)</STMTTRN>", decoded, re.DOTALL)
        data = []

        # 🔁 Loop por cada transação
        for t in raw_transactions:
            # Regex tolerante para SGML (sem fechamento e espaçamento variável)
            date = re.search(r"<DTPOSTED>(\d{8})", t)
            description = re.search(r"<MEMO>([^\r\n<]+)", t)
            amount = re.search(r"<TRNAMT>(-?\d+[.,]?\d*)", t)
            tipo = re.search(r"<TRNTYPE>([A-Z]+)", t)
            tid = re.search(r"<FITID>([^\r\n<]+)", t)

            # 🛡️ Converte a data de forma segura
            parsed_date = ""
            if date:
                try:
                    parsed_date = pd.to_datetime(date.group(1), format='%Y%m%d').date()
                except Exception:
                    parsed_date = ""

            # 🧱 Monta os dados da transação
            data.append({
                "Data": parsed_date,
                "Descrição": description.group(1).strip() if description else "",
                "Valor": float(amount.group(1).replace(',', '.')) if amount else 0.0,
                "Tipo": tipo.group(1) if tipo else "",
                "ID": tid.group(1) if tid else ""
            })

        # 🧾 Cria o DataFrame com as transações
        df = pd.DataFrame(data)

        # 👀 Mostra prévia pro usuário
        st.subheader("Prévia dos dados")
        st.dataframe(df)

        # 📦 Prepara o download
        file_name = uploaded_file.name.replace(".ofx", "") + "_convertido.xlsx"
        output = BytesIO()
        df.to_excel(output, index=False)
        output.seek(0)

        # ⬇ Botão de download
        st.download_button(
            label="Baixar arquivo convertido (.xlsx)",
            data=output,
            file_name=file_name,
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

    except Exception as e:
        st.error(f"Erro ao processar o arquivo: {e}")

# 🧾 Rodapé institucional
st.markdown("""
    <footer>
        Desenvolvido por Movendo 
        <span class="heart">💚</span> <br>
        <a href="https://www.movendo.com.br" target="_blank" style="color:#2d6a4f; text-decoration: none;">www.movendo.com.br</a>
    </footer>
""", unsafe_allow_html=True)
